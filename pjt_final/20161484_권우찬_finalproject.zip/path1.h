#ifndef __path1_
#define __path1_
void path1();
#endif 
