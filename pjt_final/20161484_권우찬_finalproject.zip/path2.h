#ifndef __path2_
#define __path2_
void path2();
#endif 
